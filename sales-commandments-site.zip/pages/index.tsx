export default function Home() {
  return <h1>Sales Commandments Site 🚀</h1>
}