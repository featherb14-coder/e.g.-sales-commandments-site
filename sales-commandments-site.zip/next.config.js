const nextConfig = {}
module.exports = nextConfig